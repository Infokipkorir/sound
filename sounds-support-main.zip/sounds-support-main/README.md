# SoundsCare Support – front end (Phase 1)

Static site (no build step). Deploy the folder to Vercel as-is.

1. In a NEW Supabase project run `soundscare_support_phase1.sql`, then `phase1b_frontend_helpers.sql`.
2. Edit `assets/config.js`: project URL + anon/publishable key (never the service_role key).
3. Supabase → Authentication → URL Configuration: add your site URL and `/login.html` as redirect URLs.
4. Make yourself platform admin (SQL at the bottom of `phase1b_frontend_helpers.sql`).

Pages: `index` · `login` · `onboarding` · `app` (client dashboard) · `admin` (owner console).

## Widget (Phase 2)
- `widget.js` is the chat bubble. Host it with the rest of the site; the install snippet in the dashboard points at it
  (set `WIDGET_URL` in `assets/config.js` to `https://YOUR-VERCEL-DOMAIN/widget.js`).
- `supabase/functions/widget/index.ts` is the server function it talks to (already deployed to the project as `widget`).
  It checks the site id, the allowed domains and a signed visitor token, then reads/writes with the service role.
- `widget-test.html?site=pk_...` loads the widget for a quick test. Add that page's domain to the site's Allowed domains first.

## Messaging (Phase 3)
Database (applied to the project as migration `phase3_messaging`): `message_deliveries`, vault wrapper functions (server-only), plan quotas.
Server functions (deployed): `providers` (save/test/delete connections, dashboard only) and `api-v1` (send SMS/email, SMS status, delivery-report webhook).
`send.ts` is shared and must stay identical in both function folders.
Run `phase1` + `phase1b` first. SMS uses Africa's Talking (adapter in `send.ts`); email uses the client's own SMTP server.
