/*! SoundsCare chat widget — install:
 *  <script src="https://YOUR-DOMAIN.com/widget.js" data-site-id="PUBLIC_SITE_ID" async></script>
 * The site id is public, not a secret. The server only answers from the domains you allow in your dashboard. */
(function () {
  "use strict";
  var me = document.currentScript || document.querySelector("script[data-site-id]");
  if (!me || window.__scWidget) return;
  var SITE = me.getAttribute("data-site-id");
  if (!SITE) return console.warn("[SoundsCare] data-site-id is missing");
  window.__scWidget = true;
  var API = me.getAttribute("data-api") || "https://eormwuvliskqurkbuzpm.supabase.co/functions/v1/widget";
  var KEY = "sc_widget_" + SITE, POLL_OPEN = 3000, POLL_CLOSED = 20000;

  var st = { token: null, after: null, seen: {}, open: false, unread: 0, timer: null, settings: null, sending: false };
  try { var saved = JSON.parse(localStorage.getItem(KEY) || "null"); if (saved && saved.token) { st.token = saved.token; st.after = saved.after || null; } } catch (e) {}
  var persist = function () { try { localStorage.setItem(KEY, JSON.stringify({ token: st.token, after: st.after })); } catch (e) {} };

  // text/plain keeps the request "simple" (no CORS preflight); the server still parses it as JSON.
  function call(body) {
    body.site_id = SITE;
    return fetch(API, { method: "POST", headers: { "Content-Type": "text/plain" }, body: JSON.stringify(body), credentials: "omit" })
      .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { if (!r.ok) { var e = new Error(j.error || "error"); e.code = j.error; e.status = r.status; throw e; } return j; }); });
  }

  call({ action: "init" }).then(function (r) { st.settings = r.settings; build(); }).catch(function (e) {
    console.warn("[SoundsCare] widget not shown:", e.code || e.message);   // wrong domain, unknown site or suspended workspace
  });

  var $, root, els = {};
  function build() {
    var s = st.settings, left = s.position === "bottom-left";
    var host = document.createElement("div");
    host.id = "soundscare-widget";
    host.style.cssText = "all:initial;position:fixed;z-index:2147483000;bottom:0;" + (left ? "left:0" : "right:0");
    document.body.appendChild(host);
    root = host.attachShadow({ mode: "open" });
    root.innerHTML =
      '<style>' +
      ':host{font:14px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}' +
      '*{box-sizing:border-box}' +
      '.wrap{position:fixed;bottom:20px;' + (left ? "left" : "right") + ':20px;display:flex;flex-direction:column;align-items:' + (left ? "flex-start" : "flex-end") + ';gap:12px}' +
      '.fab{width:58px;height:58px;border-radius:50%;border:0;background:' + s.color + ';color:#fff;cursor:pointer;box-shadow:0 6px 20px rgba(0,0,0,.25);display:grid;place-items:center;position:relative}' +
      '.fab:focus-visible,button:focus-visible,textarea:focus-visible,input:focus-visible{outline:3px solid #7aa7ff;outline-offset:2px}' +
      '.fab svg{width:28px;height:28px;fill:#fff}' +
      '.badge{position:absolute;top:-4px;right:-4px;min-width:20px;height:20px;border-radius:10px;background:#d92d20;color:#fff;font-size:12px;font-weight:700;display:none;place-items:center;padding:0 5px}' +
      '.panel{width:360px;max-width:calc(100vw - 24px);height:520px;max-height:calc(100vh - 110px);background:#fff;color:#101828;border-radius:16px;box-shadow:0 12px 48px rgba(0,0,0,.28);display:none;flex-direction:column;overflow:hidden}' +
      '.panel.on{display:flex}' +
      '.head{background:' + s.color + ';color:#fff;padding:14px 16px;display:flex;align-items:center;justify-content:space-between}' +
      '.head b{font-size:15px}.head button{background:none;border:0;color:#fff;font-size:22px;line-height:1;cursor:pointer;padding:4px 8px;border-radius:8px}' +
      '.log{flex:1;overflow:auto;padding:14px;background:#f5f7fb;display:flex;flex-direction:column;gap:8px}' +
      '.m{max-width:82%;padding:8px 12px;border-radius:14px;white-space:pre-wrap;word-wrap:break-word;overflow-wrap:anywhere}' +
      '.m.visitor{align-self:flex-end;background:' + s.color + ';color:#fff;border-bottom-right-radius:4px}' +
      '.m.agent{align-self:flex-start;background:#fff;border:1px solid #e2e7f0;border-bottom-left-radius:4px}' +
      '.m.system,.note{align-self:center;color:#5b6678;font-size:12px;text-align:center;background:none}' +
      '.err{color:#d92d20;font-size:12px;padding:0 14px 6px;min-height:18px}' +
      'form{border-top:1px solid #e2e7f0;padding:10px;display:flex;flex-direction:column;gap:8px;background:#fff}' +
      '.row{display:flex;gap:8px}' +
      'input,textarea{font:inherit;width:100%;border:1px solid #cfd6e4;border-radius:10px;padding:8px 10px;color:#101828;background:#fff}' +
      'textarea{resize:none;height:42px}' +
      '.send{background:' + s.color + ';color:#fff;border:0;border-radius:10px;padding:0 16px;font-weight:600;cursor:pointer}.send:disabled{opacity:.5;cursor:default}' +
      '.foot{font-size:11px;color:#8a94a6;text-align:center;padding:0 0 8px;background:#fff}' +
      '@media(max-width:480px){.wrap{bottom:12px;' + (left ? "left" : "right") + ':12px}.panel{width:calc(100vw - 24px);height:calc(100vh - 96px)}}' +
      '@media(prefers-reduced-motion:no-preference){.panel.on{animation:up .18s ease-out}@keyframes up{from{opacity:0;transform:translateY(10px)}}}' +
      '</style>' +
      '<div class="wrap">' +
      '<section class="panel" id="panel" role="dialog" aria-label="Chat with ' + esc(s.name) + '">' +
      '<div class="head"><b></b><button type="button" id="close" aria-label="Close chat">×</button></div>' +
      '<div class="log" id="log" role="log" aria-live="polite"></div><div class="err" id="err" role="alert"></div>' +
      '<form id="form"><div class="row" id="emailrow"><input id="email" type="email" maxlength="200" placeholder="Your email (optional, so we can reply)" aria-label="Your email, optional" autocomplete="email"></div>' +
      '<div class="row"><textarea id="body" maxlength="2000" placeholder="Type your message…" aria-label="Message" required></textarea><button class="send" id="send" type="submit">Send</button></div></form>' +
      '<div class="foot">Powered by SoundsCare</div></section>' +
      '<button class="fab" id="fab" type="button" aria-label="Open chat" aria-expanded="false"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 4h16a2 2 0 012 2v10a2 2 0 01-2 2H9l-5 4v-4a2 2 0 01-2-2V6a2 2 0 012-2z"/></svg><span class="badge" id="badge"></span></button>' +
      '</div>';
    ["panel", "log", "err", "form", "email", "emailrow", "body", "send", "fab", "badge", "close"].forEach(function (id) { els[id] = root.getElementById(id); });
    root.querySelector(".head b").textContent = s.name;
    note(s.welcome);
    els.fab.onclick = function () { toggle(!st.open); };
    els.close.onclick = function () { toggle(false); els.fab.focus(); };
    root.addEventListener("keydown", function (e) { if (e.key === "Escape" && st.open) { toggle(false); els.fab.focus(); } });
    els.body.addEventListener("keydown", function (e) { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); els.form.requestSubmit(); } });
    els.form.onsubmit = send;
    if (st.token) { els.emailrow.style.display = "none"; poll(true); } else schedule();
  }

  function esc(t) { return String(t).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function note(t) { var d = document.createElement("div"); d.className = "note"; d.textContent = t; els.log.appendChild(d); }
  function addMsg(m) {
    if (st.seen[m.id]) return false; st.seen[m.id] = 1;
    var d = document.createElement("div"); d.className = "m " + (m.sender_type === "visitor" ? "visitor" : m.sender_type === "agent" ? "agent" : "system");
    d.textContent = m.body;                                  // never innerHTML: message text is untrusted
    els.log.appendChild(d); els.log.scrollTop = els.log.scrollHeight;
    if (!st.after || m.created_at > st.after) st.after = m.created_at;
    return true;
  }
  function toggle(open) {
    st.open = open; els.panel.classList.toggle("on", open); els.fab.setAttribute("aria-expanded", open);
    els.fab.setAttribute("aria-label", open ? "Close chat" : "Open chat");
    if (open) { st.unread = 0; badge(); setTimeout(function () { els.body.focus(); }, 50); }
    schedule(true);
  }
  function badge() { els.badge.textContent = st.unread > 9 ? "9+" : st.unread; els.badge.style.display = st.unread ? "grid" : "none"; }
  function showErr(t) { els.err.textContent = t || ""; }

  function send(e) {
    e.preventDefault();
    var text = els.body.value.trim(); if (!text || st.sending) return;
    st.sending = true; els.send.disabled = true; showErr("");
    call({ action: "send", body: text, token: st.token, email: els.email.value.trim() }).then(function (r) {
      if (r.token) { st.token = r.token; els.emailrow.style.display = "none"; }
      addMsg({ id: r.message.id, sender_type: "visitor", body: text, created_at: r.message.created_at });
      persist(); els.body.value = ""; schedule(true);
    }).catch(function (er) {
      showErr(er.code === "slow_down" ? "You're sending messages too fast. Please wait a moment." :
        er.code === "unavailable" ? "Chat is unavailable right now. Please try again later." : "Message not sent. Please try again.");
    }).then(function () { st.sending = false; els.send.disabled = false; els.body.focus(); });
  }

  function poll(first) {
    if (!st.token) return schedule();
    call({ action: "poll", token: st.token, after: st.after }).then(function (r) {
      var fresh = 0;
      (r.messages || []).forEach(function (m) { if (addMsg(m) && m.sender_type !== "visitor") fresh++; });
      if (fresh && !st.open && !first) { st.unread += fresh; badge(); }
      if (first && fresh && !st.open) { st.unread = 0; }
      persist();
    }).catch(function (er) {
      if (er.status === 401) { st.token = null; st.after = null; st.seen = {}; persist(); els.emailrow.style.display = ""; }
    }).then(function () { schedule(); });
  }
  function schedule(now) {
    clearTimeout(st.timer);
    if (!st.token) return;
    st.timer = setTimeout(poll, now ? 400 : (document.hidden ? POLL_CLOSED * 2 : st.open ? POLL_OPEN : POLL_CLOSED));
  }
})();
