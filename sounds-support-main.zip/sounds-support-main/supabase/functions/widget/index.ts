// SoundsCare widget API. Public endpoint (no Supabase JWT): visitors are authenticated by
//   1) a public site id that is NOT a secret,  2) an Origin check against the site's allowed domains,
//   3) a signed visitor token (HMAC) that scopes them to exactly one conversation.
// The database is only ever touched here, with the service role. Visitors never see another visitor's data.
import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });
const enc = new TextEncoder();
const TOKEN_DAYS = 30, MAX_BODY = 2000;

// ---------- signed token ----------
const b64u = (b: ArrayBuffer | Uint8Array) => btoa(String.fromCharCode(...new Uint8Array(b))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
const unb64u = (s: string) => Uint8Array.from(atob(s.replace(/-/g, "+").replace(/_/g, "/")), (c) => c.charCodeAt(0));
let keyP: Promise<CryptoKey> | null = null;
const key = () => (keyP ??= crypto.subtle.importKey("raw",
  enc.encode("widget-visitor-token:v1:" + (Deno.env.get("WIDGET_TOKEN_SECRET") || Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!)),
  { name: "HMAC", hash: "SHA-256" }, false, ["sign", "verify"]));
async function sign(p: object) {
  const body = b64u(enc.encode(JSON.stringify(p)));
  return body + "." + b64u(await crypto.subtle.sign("HMAC", await key(), enc.encode(body)));
}
async function verify(tok: unknown): Promise<{ c: string; s: string; e: number } | null> {
  if (typeof tok !== "string" || tok.length > 600) return null;
  const [body, sig] = tok.split(".");
  if (!body || !sig) return null;
  try {
    if (!(await crypto.subtle.verify("HMAC", await key(), unb64u(sig), enc.encode(body)))) return null;
    const p = JSON.parse(new TextDecoder().decode(unb64u(body)));
    return p.e > Date.now() / 1000 ? p : null;
  } catch { return null; }
}

// ---------- helpers ----------
function originAllowed(origin: string | null, domains: string[]) {
  if (!origin) return false;
  let u: URL; try { u = new URL(origin); } catch { return false; }
  const host = u.host.toLowerCase(), name = u.hostname.toLowerCase();
  return domains.some((d) => { d = d.toLowerCase();
    return d === host || d === name || (d.startsWith("*.") && name.endsWith(d.slice(1))); });
}
const hits = new Map<string, number[]>();           // best-effort per-instance rate limit
function limited(k: string, max: number, windowMs: number) {
  const now = Date.now(), a = (hits.get(k) || []).filter((t) => now - t < windowMs);
  a.push(now); hits.set(k, a);
  if (hits.size > 5000) hits.clear();
  return a.length > max;
}
const HEX = /^#[0-9a-fA-F]{6}$/;
const clean = (s: unknown, n: number) => (typeof s === "string" ? s.replace(/[\u0000-\u001f]/g, " ").trim().slice(0, n) : "");

Deno.serve(async (req) => {
  const origin = req.headers.get("origin");
  const cors = (allow: boolean): HeadersInit => ({
    "Content-Type": "application/json", "Cache-Control": "no-store", "Vary": "Origin",
    ...(allow && origin ? { "Access-Control-Allow-Origin": origin, "Access-Control-Allow-Headers": "content-type", "Access-Control-Allow-Methods": "POST, OPTIONS" } : {}),
  });
  const out = (status: number, data: object, allow = false) => new Response(JSON.stringify(data), { status, headers: cors(allow) });
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors(true) });   // real checks happen on POST
  if (req.method !== "POST") return out(405, { error: "method_not_allowed" });

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0].trim() || "unknown";
  if (limited("ip:" + ip, 120, 60_000)) return out(429, { error: "slow_down" });

  let b: any; try { b = JSON.parse(await req.text()); } catch { return out(400, { error: "bad_request" }); }
  const action = b?.action;

  // Resolve the site and enforce tenant status + domain allow-list for every call.
  const siteId = clean(b?.site_id, 40);
  if (!/^pk_[a-z0-9]{10,40}$/.test(siteId)) return out(400, { error: "bad_site" });
  const { data: site } = await db.from("sites").select("id, tenant_id, name, allowed_domains, widget_settings, tenants(status, plan_id)").eq("public_site_id", siteId).maybeSingle();
  const tenant: any = Array.isArray(site?.tenants) ? site?.tenants[0] : site?.tenants;
  if (!site || tenant?.status !== "active") return out(404, { error: "unavailable" });
  if (!originAllowed(origin, site.allowed_domains || [])) return out(403, { error: "domain_not_allowed" });

  if (action === "init") {
    const w = site.widget_settings || {};
    return out(200, { settings: {
      name: clean(w.title || site.name, 60),
      color: HEX.test(w.primary_color) ? w.primary_color : "#1a6cf0",
      position: w.position === "bottom-left" ? "bottom-left" : "bottom-right",
      welcome: clean(w.welcome_message || "Hi! How can we help?", 200),
    } }, true);
  }

  if (action === "send") {
    const body = clean(b.body, MAX_BODY);
    if (!body) return out(400, { error: "empty" }, true);
    let tok = await verify(b.token), convId: string | null = null;

    if (tok && tok.s === site.id) {
      const { data: c } = await db.from("conversations").select("id, status").eq("id", tok.c).eq("tenant_id", site.tenant_id).eq("site_id", site.id).maybeSingle();
      if (c) convId = c.id;
    }
    if (convId && limited("conv:" + convId, 10, 60_000)) return out(429, { error: "slow_down" }, true);

    let token: string | undefined;
    if (!convId) {
      if (limited("new:" + ip, 5, 3_600_000)) return out(429, { error: "slow_down" }, true);
      // plan limit: conversations per month
      const { data: plan } = await db.from("plans").select("limits").eq("id", tenant.plan_id).maybeSingle();
      const lim = Number(plan?.limits?.conversations_per_month || 0);
      if (lim) {
        const m = new Date(); m.setUTCDate(1); m.setUTCHours(0, 0, 0, 0);
        const { count } = await db.from("conversations").select("id", { count: "exact", head: true }).eq("tenant_id", site.tenant_id).gte("created_at", m.toISOString());
        if ((count ?? 0) >= lim) return out(429, { error: "unavailable" }, true);
      }
      const email = clean(b.email, 200);
      const { data: c, error } = await db.from("conversations").insert({
        tenant_id: site.tenant_id, site_id: site.id, visitor_ref: crypto.randomUUID(),
        visitor_name: clean(b.name, 80) || null, visitor_email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ? email : null,
      }).select("id").single();
      if (error || !c) return out(500, { error: "server" }, true);
      convId = c.id;
      token = await sign({ c: convId, s: site.id, e: Math.floor(Date.now() / 1000) + TOKEN_DAYS * 86400 });
      await db.from("usage_events").insert({ tenant_id: site.tenant_id, service: "conversation", quantity: 1 });
    }
    const { data: m, error: me } = await db.from("messages").insert({ tenant_id: site.tenant_id, conversation_id: convId, sender_type: "visitor", body }).select("id, created_at").single();
    if (me || !m) return out(500, { error: "server" }, true);
    // a visitor writing again reopens a resolved/closed chat
    await db.from("conversations").update({ status: "open" }).eq("id", convId).in("status", ["resolved", "closed"]);
    return out(200, { token, message: { id: m.id, created_at: m.created_at } }, true);
  }

  if (action === "poll") {
    const tok = await verify(b.token);
    if (!tok || tok.s !== site.id) return out(401, { error: "bad_token" }, true);
    if (limited("poll:" + tok.c, 40, 60_000)) return out(429, { error: "slow_down" }, true);
    const after = typeof b.after === "string" && !isNaN(Date.parse(b.after)) ? b.after : "1970-01-01T00:00:00Z";
    const { data, error } = await db.from("messages").select("id, sender_type, body, created_at")
      .eq("tenant_id", site.tenant_id).eq("conversation_id", tok.c).gte("created_at", after).order("created_at").limit(100);
    if (error) return out(500, { error: "server" }, true);
    return out(200, { messages: data }, true);
  }

  return out(400, { error: "bad_action" }, true);
});
