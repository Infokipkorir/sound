// Dashboard-only function: save / test / delete email & SMS provider connections.
// Secrets arrive over HTTPS, go straight into Supabase Vault, and are never returned to any browser.
import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";
import { assertPublicHost, clean, E164, mask, sendEmail, sendSms, sha256hex, type Conn } from "./send.ts";

const URL_ = Deno.env.get("SUPABASE_URL")!, SRV = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const db = createClient(URL_, SRV, { auth: { persistSession: false } });
const CORS = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info", "Access-Control-Allow-Methods": "POST, OPTIONS" };
const out = (status: number, data: object) => new Response(JSON.stringify(data), { status, headers: { ...CORS, "Content-Type": "application/json", "Cache-Control": "no-store" } });
const hits = new Map<string, number[]>();
const limited = (k: string, max: number, ms: number) => { const n = Date.now(), a = (hits.get(k) || []).filter((t) => n - t < ms); a.push(n); hits.set(k, a); return a.length > max; };

const audit = (tenant: string, actor: string, action: string, target: string) =>
  db.from("audit_events").insert({ tenant_id: tenant, actor_user_id: actor, action, target, metadata: {} });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });
  if (req.method !== "POST") return out(405, { error: "method_not_allowed" });

  const jwt = (req.headers.get("authorization") || "").replace(/^Bearer /i, "");
  const { data: u } = await createClient(URL_, ANON, { auth: { persistSession: false } }).auth.getUser(jwt);
  const user = u?.user; if (!user) return out(401, { error: "not_signed_in" });
  if (limited("u:" + user.id, 30, 60_000)) return out(429, { error: "slow_down" });

  let b: any; try { b = await req.json(); } catch { return out(400, { error: "bad_request" }); }
  const tenant = clean(b.tenant_id, 40);
  const { data: m } = await db.from("tenant_members").select("role, tenants(status)").eq("tenant_id", tenant).eq("user_id", user.id).eq("status", "active").maybeSingle();
  const tStatus = (Array.isArray(m?.tenants) ? m?.tenants[0] : m?.tenants) as any;
  if (!m || tStatus?.status !== "active" || !["owner", "admin"].includes(m.role)) return out(403, { error: "forbidden" });

  // ---------- delete ----------
  if (b.action === "delete") {
    const { data: c } = await db.from("provider_connections").select("id, secret_ref").eq("id", b.id).eq("tenant_id", tenant).maybeSingle();
    if (!c) return out(404, { error: "not_found" });
    if (c.secret_ref) await db.rpc("delete_provider_secret", { p_id: c.secret_ref });
    await db.from("provider_connections").delete().eq("id", c.id).eq("tenant_id", tenant);
    await audit(tenant, user.id, "provider.deleted", c.id);
    return out(200, { ok: true });
  }

  // ---------- save ----------
  if (b.action === "save") {
    const type = b.provider_type, cfg = b.config || {}, label = clean(b.label, 80), secret = typeof b.secret === "string" ? b.secret : "";
    if (!label) return out(400, { error: "label_required" });
    let config: Record<string, unknown>;
    if (type === "smtp") {
      const port = Number(cfg.port);
      config = { host: clean(cfg.host, 200).toLowerCase(), port, security: cfg.security === "ssl" ? "ssl" : "starttls",
        username: clean(cfg.username, 200), from_email: clean(cfg.from_email, 200), from_name: clean(cfg.from_name, 80) };
      if (![465, 587, 2525].includes(port)) return out(400, { error: "bad_port", detail: "Use port 465, 587 or 2525." });
      if (!/^[^\s@<>()]+@[^\s@<>()]+\.[^\s@<>()]+$/.test(config.from_email as string)) return out(400, { error: "bad_from" });
      try { await assertPublicHost(config.host as string); } catch (e) { return out(400, { error: (e as Error).message, detail: "That mail server address isn't reachable or isn't allowed." }); }
    } else if (type === "sms") {
      config = { provider: "africastalking", username: clean(cfg.username, 80), sender_id: clean(cfg.sender_id, 11), sandbox: !!cfg.sandbox };
      if (!config.username) return out(400, { error: "username_required" });
      if (config.sender_id && !/^[A-Za-z0-9]{1,11}$/.test(config.sender_id as string)) return out(400, { error: "bad_sender_id" });
    } else return out(400, { error: "bad_type" });

    let id = b.id as string | undefined, secretRef: string | null = null, callback: { url: string; token: string } | undefined;
    if (id) {
      const { data: ex } = await db.from("provider_connections").select("id, secret_ref, provider_type, config").eq("id", id).eq("tenant_id", tenant).maybeSingle();
      if (!ex || ex.provider_type !== type) return out(404, { error: "not_found" });
      secretRef = ex.secret_ref;
      if (type === "sms" && ex.config?.callback_hash) config.callback_hash = ex.config.callback_hash;
      if (secret) {
        if (secretRef) await db.rpc("update_provider_secret", { p_id: secretRef, p_secret: secret });
        else { const r = await db.rpc("store_provider_secret", { p_name: `provider:${tenant}:${id}`, p_secret: secret }); secretRef = r.data; }
      } else if (!secretRef) return out(400, { error: "secret_required" });
      const { error } = await db.from("provider_connections").update({ label, config, secret_ref: secretRef, status: "untested" }).eq("id", id).eq("tenant_id", tenant);
      if (error) return out(500, { error: "server" });
    } else {
      if (!secret) return out(400, { error: "secret_required" });
      id = crypto.randomUUID();
      const r = await db.rpc("store_provider_secret", { p_name: `provider:${tenant}:${id}`, p_secret: secret });
      if (r.error || !r.data) return out(500, { error: "server" });
      secretRef = r.data;
      if (type === "sms") {                       // per-connection token so only the provider can post delivery reports
        const token = crypto.randomUUID().replace(/-/g, "") + crypto.randomUUID().replace(/-/g, "");
        config.callback_hash = await sha256hex(token);
        callback = { token, url: `${URL_}/functions/v1/api-v1/webhooks/sms?c=${id}&t=${token}` };
      }
      const { error } = await db.from("provider_connections").insert({ id, tenant_id: tenant, provider_type: type, label, config, secret_ref: secretRef });
      if (error) { await db.rpc("delete_provider_secret", { p_id: secretRef }); return out(500, { error: "server" }); }
    }
    await audit(tenant, user.id, b.id ? "provider.updated" : "provider.created", id!);
    return out(200, { id, callback });
  }

  // ---------- test ----------
  if (b.action === "test") {
    if (limited("t:" + tenant, 10, 3_600_000)) return out(429, { error: "slow_down" });
    const { data: c } = await db.from("provider_connections").select("id, provider_type, config, secret_ref").eq("id", b.id).eq("tenant_id", tenant).maybeSingle();
    if (!c || !c.secret_ref) return out(404, { error: "not_found" });
    const secret = (await db.rpc("read_provider_secret", { p_id: c.secret_ref })).data as string;
    let error: string | null = null;
    try {
      if (c.provider_type === "smtp") {
        // test mail goes only to the signed-in person's own address, so this can't be used to spam others
        await sendEmail(c as Conn, secret, { to: user.email!, subject: "SoundsCare test email", text: "Your SMTP connection works. You can ignore this message." });
      } else {
        const to = clean(b.to, 20);
        if (!E164.test(to)) return out(400, { error: "bad_number", detail: "Use international format, e.g. +254712345678." });
        await sendSms(c as Conn, secret, { to, message: "SoundsCare test message: your SMS connection works." });
      }
    } catch (e) { error = (e as Error).message.replace(/[^a-z0-9_ .:-]/gi, "").slice(0, 120) || "failed"; }
    await db.from("provider_connections").update({ status: error ? "failing" : "ok" }).eq("id", c.id).eq("tenant_id", tenant);
    await audit(tenant, user.id, error ? "provider.test_failed" : "provider.test_ok", c.id);
    return out(200, { ok: !error, error, sent_to: c.provider_type === "smtp" ? mask(user.email!) : mask(clean(b.to, 20)) });
  }
  return out(400, { error: "bad_action" });
});
