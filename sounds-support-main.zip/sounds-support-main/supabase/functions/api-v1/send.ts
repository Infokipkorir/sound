// Shared sender code (copied into each function that needs it). Never logs secrets or message bodies.
import { SMTPClient } from "https://deno.land/x/denomailer@1.6.0/mod.ts";

export const E164 = /^\+[1-9]\d{7,14}$/;
export const EMAIL = /^[^\s@<>()]+@[^\s@<>()]+\.[^\s@<>()]+$/;
export const mask = (v: string) => v.includes("@") ? v.replace(/^(.).*(@.*)$/, "$1***$2") : v.slice(0, 4) + "****" + v.slice(-3);
export const clean = (s: unknown, n: number) => (typeof s === "string" ? s.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "").trim().slice(0, n) : "");
export const noCRLF = (s: string) => s.replace(/[\r\n]+/g, " ");        // header-injection guard

export async function sha256hex(s: string) {
  const d = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
  return [...new Uint8Array(d)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

// Block SMTP hosts that point into private/internal networks (SSRF guard).
function privateIp(ip: string) {
  if (ip.includes(":")) return /^(::1|fc|fd|fe80)/i.test(ip) || ip === "::";
  const [a, b] = ip.split(".").map(Number);
  return a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127);
}
export async function assertPublicHost(host: string) {
  if (!/^[a-z0-9]([a-z0-9.-]*[a-z0-9])?$/i.test(host) || host === "localhost" || host.endsWith(".internal") || host.endsWith(".local")) throw new Error("bad_host");
  if (/^[\d.]+$/.test(host)) { if (privateIp(host)) throw new Error("bad_host"); return; }
  let ips: string[] = [];
  try { ips = [...await Deno.resolveDns(host, "A"), ...await Deno.resolveDns(host, "AAAA").catch(() => [])]; } catch { throw new Error("host_not_found"); }
  if (!ips.length || ips.some(privateIp)) throw new Error("bad_host");
}

export type Conn = { provider_type: string; config: Record<string, any> };

export async function sendEmail(conn: Conn, password: string, m: { to: string; subject: string; text: string }) {
  const c = conn.config;
  await assertPublicHost(c.host);
  const client = new SMTPClient({
    connection: { hostname: c.host, port: Number(c.port), tls: c.security === "ssl", auth: { username: c.username, password } },
  });
  try {
    await client.send({ from: c.from_name ? `${noCRLF(c.from_name)} <${c.from_email}>` : c.from_email, to: m.to, subject: noCRLF(m.subject), content: m.text });
  } finally { try { await client.close(); } catch { /* ignore */ } }
  return { provider_ref: null as string | null, cost: null as number | null };
}

// Africa's Talking adapter. Add other SMS providers here with the same return shape.
export async function sendSms(conn: Conn, apiKey: string, m: { to: string; message: string }) {
  const c = conn.config;
  const base = c.sandbox ? "https://api.sandbox.africastalking.com" : "https://api.africastalking.com";
  const form = new URLSearchParams({ username: c.username, to: m.to, message: m.message });
  if (c.sender_id) form.set("from", c.sender_id);
  const r = await fetch(`${base}/version1/messaging`, {
    method: "POST", headers: { apiKey, Accept: "application/json", "Content-Type": "application/x-www-form-urlencoded" }, body: form,
    signal: AbortSignal.timeout(15000),
  });
  if (r.status >= 500) throw Object.assign(new Error("provider_unavailable"), { transient: true });
  if (r.status === 401) throw new Error("provider_auth_failed");
  const j = await r.json().catch(() => ({}));
  const rec = j?.SMSMessageData?.Recipients?.[0];
  if (!rec) throw new Error("provider_rejected");
  if (![100, 101, 102].includes(Number(rec.statusCode))) throw new Error("provider_" + String(rec.status || rec.statusCode).toLowerCase().replace(/[^a-z0-9]+/g, "_").slice(0, 40));
  const cost = parseFloat(String(rec.cost || "").replace(/[^0-9.]/g, ""));
  return { provider_ref: String(rec.messageId || ""), cost: isNaN(cost) ? null : cost };
}
