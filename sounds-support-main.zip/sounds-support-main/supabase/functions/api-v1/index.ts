// Public REST API, server-to-server. Authenticated by a scoped, revocable key (sc_live_...), never by a browser session.
//   POST /api-v1/sms/send        {to, message}          scope sms:send    (header Idempotency-Key recommended)
//   GET  /api-v1/sms/status/:id                          scope sms:send
//   POST /api-v1/email/send      {to, subject, text}    scope email:send
//   POST /api-v1/webhooks/sms?c=<connection>&t=<token>   delivery reports from the SMS provider (token-authenticated)
import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";
import { clean, E164, EMAIL, mask, sendEmail, sendSms, sha256hex, type Conn } from "./send.ts";

const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });
const hits = new Map<string, number[]>();
const limited = (k: string, max: number, ms: number) => { const n = Date.now(), a = (hits.get(k) || []).filter((t) => n - t < ms); a.push(n); hits.set(k, a); if (hits.size > 5000) hits.clear(); return a.length > max; };

Deno.serve(async (req) => {
  const rid = "req_" + crypto.randomUUID().replace(/-/g, "").slice(0, 20);
  const out = (status: number, data: object) => new Response(JSON.stringify({ ...data, request_id: rid }), { status, headers: { "Content-Type": "application/json", "X-Request-Id": rid, "Cache-Control": "no-store" } });
  const err = (status: number, code: string, message: string) => out(status, { error: { code, message } });

  const url = new URL(req.url);
  const path = url.pathname.replace(/^.*\/api-v1/, "") || "/";

  // ---------- delivery reports from the SMS provider ----------
  if (path === "/webhooks/sms") {
    const ip = req.headers.get("x-forwarded-for")?.split(",")[0].trim() || "x";
    if (limited("wh:" + ip, 300, 60_000)) return err(429, "rate_limited", "Slow down.");
    const cid = clean(url.searchParams.get("c"), 40), tok = clean(url.searchParams.get("t"), 100);
    const { data: c } = await db.from("provider_connections").select("id, tenant_id, config").eq("id", cid).eq("provider_type", "sms").maybeSingle();
    if (!c || !tok || (await sha256hex(tok)) !== c.config?.callback_hash) return err(401, "unauthorized", "Bad callback token.");
    const f = req.method === "POST" ? new URLSearchParams(await req.text()) : url.searchParams;
    const ref = clean(f.get("id"), 80), st = clean(f.get("status"), 30).toLowerCase();
    const status = st === "success" || st === "delivered" ? "delivered" : ["failed", "rejected", "undelivered"].includes(st) ? "failed" : "sent";
    if (ref) await db.from("message_deliveries").update({ status, error_code: status === "failed" ? clean(f.get("failureReason"), 60) || "failed" : null })
      .eq("tenant_id", c.tenant_id).eq("provider_ref", ref).neq("status", "delivered");
    return out(200, { ok: true });
  }

  // ---------- authenticate the API key ----------
  const key = (req.headers.get("authorization") || "").replace(/^Bearer /i, "").trim();
  if (!/^sc_live_[a-f0-9]{64}$/.test(key)) return err(401, "unauthorized", "Missing or malformed API key. Send 'Authorization: Bearer sc_live_...'.");
  const hash = "\\x" + await sha256hex(key);   // key_hash stores sha256 of the UTF-8 key
  const { data: cred } = await db.from("api_credentials").select("id, tenant_id, scopes, expires_at, revoked_at").eq("key_hash", hash).maybeSingle();
  if (!cred || cred.revoked_at || (cred.expires_at && new Date(cred.expires_at) < new Date())) return err(401, "unauthorized", "Invalid, revoked or expired API key.");
  if (limited("k:" + cred.id, 60, 60_000)) return err(429, "rate_limited", "Limit is 60 requests per minute per key.");
  db.from("api_credentials").update({ last_used_at: new Date().toISOString() }).eq("id", cred.id).then(() => {});

  const tenant = cred.tenant_id;
  const { data: t } = await db.from("tenants").select("status, plans(limits, features)").eq("id", tenant).maybeSingle();
  const plan: any = Array.isArray(t?.plans) ? t?.plans[0] : t?.plans;
  if (t?.status !== "active") return err(403, "workspace_suspended", "This workspace is not active.");
  const need = (scope: string) => cred.scopes.includes(scope);

  async function usedThisMonth(service: string) {
    const m = new Date(); m.setUTCDate(1); m.setUTCHours(0, 0, 0, 0);
    const { data } = await db.from("usage_events").select("quantity").eq("tenant_id", tenant).eq("service", service).gte("created_at", m.toISOString()).limit(100000);
    return (data || []).reduce((s, r: any) => s + Number(r.quantity), 0);
  }
  async function connection(type: string) {
    const { data } = await db.from("provider_connections").select("id, provider_type, config, secret_ref").eq("tenant_id", tenant).eq("provider_type", type).neq("status", "disabled").order("created_at", { ascending: false }).limit(1).maybeSingle();
    return data;
  }
  async function body() { try { return await req.json(); } catch { return null; } }

  // ---------- SMS status ----------
  const st = path.match(/^\/sms\/status\/([0-9a-f-]{36})$/);
  if (st && req.method === "GET") {
    if (!need("sms:send")) return err(403, "forbidden", "This key lacks the sms:send scope.");
    const { data } = await db.from("message_deliveries").select("id, status, error_code, created_at, updated_at").eq("tenant_id", tenant).eq("id", st[1]).eq("channel", "sms").maybeSingle();
    return data ? out(200, data) : err(404, "not_found", "No such message.");
  }

  // ---------- send (SMS or email) ----------
  const channel = path === "/sms/send" ? "sms" : path === "/email/send" ? "email" : null;
  if (!channel) return err(404, "not_found", "Unknown endpoint.");
  if (req.method !== "POST") return err(405, "method_not_allowed", "Use POST.");
  if (!need(channel === "sms" ? "sms:send" : "email:send")) return err(403, "forbidden", `This key lacks the ${channel === "sms" ? "sms:send" : "email:send"} scope.`);
  if (!plan?.features?.[channel === "sms" ? "sms" : "smtp"]) return err(402, "plan_required", `Your plan does not include ${channel === "sms" ? "SMS" : "email"} sending.`);

  const b = await body(); if (!b) return err(400, "invalid_json", "Body must be JSON.");
  const to = clean(b.to, 200);
  let message = "", subject = "";
  if (channel === "sms") {
    message = clean(b.message, 480);
    if (!E164.test(to)) return err(422, "invalid_recipient", "'to' must be an international number like +254712345678.");
    if (!message) return err(422, "invalid_message", "'message' is required (max 480 characters).");
  } else {
    subject = clean(b.subject, 200); message = clean(b.text, 10000);
    if (!EMAIL.test(to)) return err(422, "invalid_recipient", "'to' must be a valid email address.");
    if (!subject || !message) return err(422, "invalid_message", "'subject' and 'text' are required (plain text only).");
  }

  const idem = clean(req.headers.get("idempotency-key") || b.idempotency_key, 80) || null;
  let attempts = 1, id = "";
  if (idem) {
    const { data: ex } = await db.from("message_deliveries").select("id, status, attempts").eq("tenant_id", tenant).eq("idempotency_key", idem).maybeSingle();
    if (ex && ex.status !== "failed") return out(200, { id: ex.id, status: ex.status, idempotent_replay: true });
    if (ex) { id = ex.id; attempts = ex.attempts + 1; }              // a failed send may be retried with the same key
  }

  const service = channel === "sms" ? "sms" : "email";
  const limit = Number(plan?.limits?.[channel === "sms" ? "sms_per_month" : "emails_per_month"] || 0);
  if (limit && (await usedThisMonth(service)) >= limit) return err(429, "quota_exceeded", "Monthly message quota reached.");

  const conn = await connection(channel === "sms" ? "sms" : "smtp");
  if (!conn || !conn.secret_ref) return err(409, "no_provider", `No ${channel === "sms" ? "SMS" : "SMTP"} provider is configured for this workspace.`);

  if (!id) {
    const ins = await db.from("message_deliveries").insert({ tenant_id: tenant, connection_id: conn.id, channel, recipient_masked: mask(to), idempotency_key: idem, request_id: rid, attempts: 1 }).select("id").single();
    if (ins.error) {
      if (idem && ins.error.code === "23505") return err(409, "request_in_progress", "A request with this Idempotency-Key is already being processed.");
      return err(500, "server_error", "Could not record the message.");
    }
    id = ins.data.id;
  }

  const secret = (await db.rpc("read_provider_secret", { p_id: conn.secret_ref })).data as string;
  try {
    const r = channel === "sms" ? await sendSms(conn as Conn, secret, { to, message }) : await sendEmail(conn as Conn, secret, { to, subject, text: message });
    await db.from("message_deliveries").update({ status: "sent", provider_ref: r.provider_ref, cost: r.cost, attempts, error_code: null }).eq("id", id).eq("tenant_id", tenant);
    await db.from("usage_events").insert({ tenant_id: tenant, service, quantity: 1, provider_cost: r.cost });
    return out(202, { id: id, status: "sent", note: "Accepted by the provider. Delivery is only confirmed when status becomes 'delivered'." });
  } catch (e) {
    const code = (e as Error).message.replace(/[^a-z0-9_]/gi, "").slice(0, 60) || "send_failed";
    await db.from("message_deliveries").update({ status: "failed", error_code: code, attempts }).eq("id", id).eq("tenant_id", tenant);
    return err((e as any).transient ? 502 : 422, code, "The provider did not accept the message. " + ((e as any).transient ? "Retry with the same Idempotency-Key." : "Check the provider settings."));
  }
});
