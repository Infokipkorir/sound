// API guard for the public API (api-v1). Wire it in like this:
//
//   import { guardPre, guardFail, guardKey } from "../_shared/guard.ts";
//
//   if (req.method === "OPTIONS") return new Response(null, { status: 204 });   // NO CORS headers: browsers must not use this API
//   const blocked = await guardPre(sb, req);            // 1. kill switch + blocked IPs
//   if (blocked) return blocked;
//   const cred = await yourExistingKeyLookup(req);       //    verify the Bearer key as you already do
//   if (!cred) { await guardFail(sb, req); return new Response(JSON.stringify({ error: "invalid_key" }), { status: 401 }); }
//   const stop = await guardKey(sb, req, cred.id);       // 2. suspension, billing, browser-exposure, flood, rate limit
//   if (stop) return stop;
//   ... handle the request ...
//
// `sb` must be the service-role client. The guard fails closed: if the database check errors, the request is refused.
import type { SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

export const clientIp = (req: Request) =>
  req.headers.get("cf-connecting-ip") || req.headers.get("x-forwarded-for")?.split(",")[0].trim() || req.headers.get("x-real-ip") || "unknown";

const MESSAGES: Record<string, string> = {
  api_disabled: "The API is temporarily disabled.",
  ip_blocked: "Too many invalid requests from this address. Try again later.",
  key_revoked: "This key has been revoked.",
  key_suspended: "This key was suspended for security reasons. Contact your workspace owner or SoundsCare support.",
  workspace_api_suspended: "API access for this workspace is suspended.",
  billing_inactive: "This workspace's trial or subscription has ended.",
  rate_limited: "Rate limit exceeded.",
};

function deny(d: { reason: string; status?: number; retry_after?: number }) {
  const h: Record<string, string> = { "Content-Type": "application/json" };
  if (d.retry_after) h["Retry-After"] = String(d.retry_after);
  return new Response(JSON.stringify({ error: d.reason, message: MESSAGES[d.reason] ?? "Request refused." }), { status: d.status ?? 403, headers: h });
}
const unavailable = () => deny({ reason: "api_disabled", status: 503, retry_after: 30 });

export async function guardPre(sb: SupabaseClient, req: Request): Promise<Response | null> {
  const { data, error } = await sb.rpc("api_guard_precheck", { p_ip: clientIp(req) });
  if (error || !data) return unavailable();
  return data.allowed ? null : deny(data);
}
export async function guardFail(sb: SupabaseClient, req: Request) {
  await sb.rpc("api_guard_auth_fail", { p_ip: clientIp(req) });
}
export async function guardKey(sb: SupabaseClient, req: Request, keyId: string): Promise<Response | null> {
  const { data, error } = await sb.rpc("api_guard_check", { p_key: keyId, p_ip: clientIp(req), p_origin: req.headers.get("origin") ?? "" });
  if (error || !data) return unavailable();
  return data.allowed ? null : deny(data);
}
