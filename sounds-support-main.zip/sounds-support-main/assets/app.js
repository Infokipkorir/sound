/* Client workspace dashboard. All data access goes through Supabase RLS; the UI only hides what a role can't use. */
if (SC.requireConfig()) (async () => {
  const { $, esc, db } = SC;
  const sess = await SC.requireSession(); if (!sess) return;
  const uid = sess.user.id;
  $("#who").textContent = sess.user.email;
  $("#out").onclick = (e) => { e.preventDefault(); SC.signOut(); };
  $("#menu").onclick = () => $("#side").classList.toggle("open");

  // ---------- who am I, in which workspaces ----------
  const { data: mems, error: memErr } = await db.from("tenant_members")
    .select("tenant_id, role, status, tenants(id, name, slug, status, plan_id)")
    .eq("user_id", uid).eq("status", "active");
  if (memErr) { $("#view").innerHTML = `<div class="notice bad">${esc(SC.friendly(memErr))}</div>`; return; }
  const spaces = (mems || []).filter((m) => m.tenants);
  if (!spaces.length) return location.replace("onboarding.html");

  let cur = spaces.find((m) => m.tenant_id === localStorage.getItem("sc_tenant")) || spaces[0];
  const T = () => cur.tenant_id, ROLE = () => cur.role;
  const isAdmin = () => ["owner", "admin"].includes(ROLE());
  const canInbox = () => ["owner", "admin", "agent"].includes(ROLE());

  const { data: plans } = await db.from("plans").select("*");
  const planOf = () => (plans || []).find((p) => p.id === cur.tenants.plan_id);

  // Is this person also a platform admin? Needs the optional helper in phase1b_frontend_helpers.sql.
  let isPlatform = false;
  try { const r = await db.rpc("am_i_platform_admin"); isPlatform = r.data === true; } catch {}

  // ---------- shell ----------
  const NAV = [
    ["overview", "Overview", "grid-1x2", () => true],
    ["inbox", "Conversations", "chat-dots", canInbox],
    ["tickets", "Tickets", "ticket-perforated", canInbox],
    ["_", "Workspace"],
    ["sites", "Websites & widget", "globe2", () => true],
    ["team", "Team", "people", () => isAdmin()],
    ["integrations", "Email & SMS", "envelope-at", () => isAdmin() || ROLE() === "developer"],
    ["api", "API keys", "key", () => isAdmin() || ROLE() === "developer"],
    ["_", "Trust"],
    ["privacy", "Privacy & support access", "shield-lock", () => isAdmin()],
    ["activity", "Activity log", "clock-history", () => isAdmin()],
  ];
  function drawShell() {
    $("#ws-switch").innerHTML = `
      <label class="small muted" for="ws">Workspace</label>
      <select id="ws">${spaces.map((m) => `<option value="${m.tenant_id}" ${m === cur ? "selected" : ""}>${esc(m.tenants.name)}</option>`).join("")}</select>
      <div class="small muted" style="margin-top:.35rem">${SC.badge(cur.tenants.status)} ${esc(ROLE())} · ${esc(planOf()?.name || "No plan")}
      · <a href="onboarding.html">New</a></div>`;
    $("#ws").onchange = (e) => { cur = spaces.find((m) => m.tenant_id === e.target.value); localStorage.setItem("sc_tenant", T()); drawShell(); route(); };
    $("#nav").innerHTML = NAV.filter((n) => n[0] === "_" || n[3]()).map((n) =>
      n[0] === "_" ? `<div class="sect">${n[1]}</div>` : `<a href="#/${n[0]}" data-r="${n[0]}"><i class="bi bi-${n[2]}" aria-hidden="true"></i>${n[1]}</a>`).join("")
      + (isPlatform ? `<div class="sect">Platform</div><a href="admin.html"><i class="bi bi-gear" aria-hidden="true"></i>Owner console</a>` : "");
  }

  // ---------- router ----------
  let cleanup = null;
  const views = { overview, inbox, tickets, sites, team, integrations, api, privacy, activity };
  async function route() {
    const r = (location.hash.replace(/^#\//, "") || "overview").split("?")[0];
    const allowed = NAV.find((n) => n[0] === r && n[0] !== "_" && n[3]());
    const name = allowed ? r : "overview";
    if (cleanup) { cleanup(); cleanup = null; }
    $("#side").classList.remove("open");
    SC.$$("#nav a").forEach((a) => a.classList.toggle("on", a.dataset.r === name));
    $("#title").textContent = NAV.find((n) => n[0] === name)[1];
    $("#actions").innerHTML = "";
    $("#view").innerHTML = '<div class="empty"><span class="spin"></span></div>';
    if (cur.tenants.status !== "active") {
      $("#view").innerHTML = `<div class="notice bad"><b>This workspace is ${esc(cur.tenants.status)}.</b> Access to conversations and settings is switched off. Contact SoundsCare support.</div>`;
      return;
    }
    try { cleanup = (await views[name]()) || null; }
    catch (e) { console.error(e); $("#view").innerHTML = `<div class="notice bad">${esc(SC.friendly(e))}</div>`; }
  }
  window.addEventListener("hashchange", route);

  const must = (r) => { if (r.error) throw r.error; return r.data; };
  const count = async (table, f) => { let q = db.from(table).select("*", { count: "exact", head: true }).eq("tenant_id", T()); if (f) q = f(q); const r = await q; return r.error ? "–" : r.count; };
  const shortId = (id) => (id ? id.slice(0, 8) : "");
  const name = (c) => c.visitor_name || (c.visitor_email ? c.visitor_email : "Visitor " + shortId(c.visitor_ref));
  const STATUSES = ["open", "pending", "resolved", "closed"], PRIOS = ["low", "normal", "high", "urgent"], TSTAT = ["new", "open", "waiting", "resolved", "closed"];
  const opts = (arr, sel) => arr.map((x) => `<option ${x === sel ? "selected" : ""}>${x}</option>`).join("");

  // ================= OVERVIEW =================
  async function overview() {
    const plan = planOf(), lim = plan?.limits || {};
    const [oc, ot, ns, nm] = await Promise.all([
      canInbox() ? count("conversations", (q) => q.in("status", ["open", "pending"])) : "–",
      canInbox() ? count("tickets", (q) => q.in("status", ["new", "open", "waiting"])) : "–",
      count("sites"), isAdmin() ? count("tenant_members", (q) => q.eq("status", "active")) : "–"]);
    let usage = [];
    if (isAdmin()) {
      const since = new Date(); since.setDate(1); since.setHours(0, 0, 0, 0);
      const r = await db.from("usage_events").select("service, quantity").eq("tenant_id", T()).gte("created_at", since.toISOString());
      const agg = {}; (r.data || []).forEach((u) => (agg[u.service] = (agg[u.service] || 0) + Number(u.quantity)));
      usage = Object.entries(agg);
    }
    const lm = (k) => (lim[k] ? ` <span class="muted small">/ ${lim[k]}</span>` : "");
    $("#view").innerHTML = `
      <div class="grid g4">
        <div class="card stat"><div class="n">${oc}</div><div class="l">Open conversations</div></div>
        <div class="card stat"><div class="n">${ot}</div><div class="l">Open tickets</div></div>
        <div class="card stat"><div class="n">${ns}${lm("sites")}</div><div class="l">Websites</div></div>
        <div class="card stat"><div class="n">${nm}${lm("agents")}</div><div class="l">Team members</div></div>
      </div>
      <div class="grid g2" style="margin-top:1rem">
        <div class="card"><h2>Get started</h2>
          <ol style="padding-left:1.1rem;margin:0" class="small">
            <li>Add your website under <a href="#/sites">Websites &amp; widget</a> and list its allowed domains.</li>
            <li>Copy the install snippet into your site.</li>
            <li>Invite agents from <a href="#/team">Team</a>.</li>
            <li>Reply to visitors from <a href="#/inbox">Conversations</a>.</li>
          </ol></div>
        <div class="card"><h2>Plan: ${esc(plan?.name || "—")}</h2>
          <p class="small muted" style="margin-top:0">${lim.conversations_per_month ? `Up to ${lim.conversations_per_month.toLocaleString()} conversations a month.` : "Custom limits."}</p>
          ${isAdmin() ? `<h3 style="margin:.5rem 0 .3rem" class="small">Usage this month</h3>` + (usage.length ? usage.map(([s, q]) => `<div class="row between small"><span>${esc(s)}</span><b>${q.toLocaleString()}</b></div>`).join("") : '<div class="small muted">No metered usage yet.</div>') : ""}
        </div>
      </div>`;
  }

  // ================= INBOX =================
  async function inbox() {
    let filter = "open", selId = null, convs = [], chans = [];
    $("#view").innerHTML = `
      <div class="row" style="margin-bottom:.75rem"><div class="tabs" id="ftabs" style="margin:0">${["open", "pending", "resolved", "closed", "all"].map((s) => `<button data-s="${s}" class="${s === filter ? "on" : ""}">${s}</button>`).join("")}</div></div>
      <div class="inbox" id="inbox"><div class="card list" id="list"></div><div class="card thread" id="thread"><div class="empty">Select a conversation</div></div></div>`;
    SC.$$("#ftabs button").forEach((b) => (b.onclick = () => { filter = b.dataset.s; SC.$$("#ftabs button").forEach((x) => x.classList.toggle("on", x === b)); load(); }));

    async function load() {
      let q = db.from("conversations").select("*").eq("tenant_id", T()).order("last_message_at", { ascending: false }).limit(100);
      if (filter !== "all") q = q.eq("status", filter);
      convs = must(await q); drawList();
    }
    function drawList() {
      $("#list").innerHTML = convs.length ? convs.map((c) => `
        <div class="conv ${c.id === selId ? "on" : ""}" data-id="${c.id}">
          <div class="row between"><b>${esc(name(c))}</b><span class="small muted">${SC.ago(c.last_message_at)}</span></div>
          <div class="small">${SC.badge(c.status)} ${SC.badge(c.priority)} ${c.assigned_agent_id === uid ? '<span class="badge info">mine</span>' : ""}</div>
        </div>`).join("") : '<div class="empty">No conversations here yet.<br><span class="small">They appear when a visitor writes in through your widget.</span></div>';
      SC.$$(".conv", $("#list")).forEach((el) => (el.onclick = () => open(el.dataset.id)));
    }
    async function open(id) {
      selId = id; $("#inbox").classList.add("has-sel"); drawList();
      const c = convs.find((x) => x.id === id); if (!c) return;
      const msgs = must(await db.from("messages").select("id, sender_type, sender_user_id, body, created_at").eq("tenant_id", T()).eq("conversation_id", id).order("created_at"));
      $("#thread").innerHTML = `
        <div class="thread-head">
          <div class="row between"><div><button class="btn sm ghost menu-btn" id="back"><i class="bi bi-arrow-left" aria-hidden="true"></i> Back</button><b>${esc(name(c))}</b>
            <div class="small muted">${esc(c.visitor_email || "No email given")} · started ${SC.dt(c.created_at)}</div></div>
            <button class="btn sm" id="mk"><i class="bi bi-ticket-perforated" aria-hidden="true"></i> Create ticket</button></div>
          <div class="row" style="margin-top:.5rem">
            <select id="st" style="width:auto" aria-label="Status">${opts(STATUSES, c.status)}</select>
            <select id="pr" style="width:auto" aria-label="Priority">${opts(PRIOS, c.priority)}</select>
            <select id="as" style="width:auto" aria-label="Assignee"><option value="">Unassigned</option><option value="${uid}" ${c.assigned_agent_id === uid ? "selected" : ""}>Me</option>
              ${c.assigned_agent_id && c.assigned_agent_id !== uid ? `<option value="${c.assigned_agent_id}" selected>Agent ${shortId(c.assigned_agent_id)}</option>` : ""}</select>
          </div></div>
        <div class="msgs" id="msgs"></div>
        <form class="composer" id="send"><textarea id="body" maxlength="8000" placeholder="Write a reply…" aria-label="Reply" required></textarea><button class="btn primary" id="sendbtn">Send</button></form>`;
      $("#back").onclick = () => { selId = null; $("#inbox").classList.remove("has-sel"); drawList(); };
      msgs.forEach(addMsg); scroll();
      const patch = async (p) => { const r = await db.from("conversations").update(p).eq("id", id).eq("tenant_id", T()); if (r.error) SC.toast(SC.friendly(r.error), true); else { Object.assign(c, p); drawList(); } };
      $("#st").onchange = (e) => patch({ status: e.target.value });
      $("#pr").onchange = (e) => patch({ priority: e.target.value });
      $("#as").onchange = (e) => patch({ assigned_agent_id: e.target.value || null });
      $("#mk").onclick = async () => {
        const r = await db.from("tickets").insert({ tenant_id: T(), conversation_id: id, subject: ("Chat with " + name(c)).slice(0, 200), priority: c.priority }).select("ticket_number").single();
        r.error ? SC.toast(SC.friendly(r.error), true) : SC.toast("Ticket #" + r.data.ticket_number + " created");
      };
      $("#send").onsubmit = async (e) => {
        e.preventDefault(); const body = $("#body").value.trim(); if (!body) return;
        $("#sendbtn").disabled = true;
        const r = await db.from("messages").insert({ tenant_id: T(), conversation_id: id, sender_type: "agent", sender_user_id: uid, body }).select("id, sender_type, sender_user_id, body, created_at").single();
        $("#sendbtn").disabled = false;
        if (r.error) return SC.toast(SC.friendly(r.error), true);
        $("#body").value = ""; addMsg(r.data); scroll();
      };
      // realtime for this conversation (RLS applies to realtime too)
      chans.forEach((ch) => db.removeChannel(ch)); chans = [];
      chans.push(db.channel("msg-" + id).on("postgres_changes", { event: "INSERT", schema: "public", table: "messages", filter: "conversation_id=eq." + id },
        (p) => { addMsg(p.new); scroll(); }).subscribe());
    }
    const seen = new Set();
    function addMsg(m) {
      const box = $("#msgs"); if (!box || box.querySelector(`[data-m="${m.id}"]`)) return;
      const d = document.createElement("div");
      d.className = "bubble " + m.sender_type; d.dataset.m = m.id;
      d.textContent = m.body;                                       // textContent: visitor text is never parsed as HTML
      const t = document.createElement("small"); t.textContent = SC.dt(m.created_at); d.appendChild(t);
      box.appendChild(d);
    }
    const scroll = () => { const b = $("#msgs"); if (b) b.scrollTop = b.scrollHeight; };

    await load();
    chans.push(db.channel("convs-" + T()).on("postgres_changes", { event: "*", schema: "public", table: "conversations", filter: "tenant_id=eq." + T() }, () => load()).subscribe());
    return () => chans.forEach((ch) => db.removeChannel(ch));
  }

  // ================= TICKETS =================
  async function tickets() {
    const plan = planOf();
    let filter = "active";
    $("#actions").innerHTML = '<button class="btn primary" id="new"><i class="bi bi-plus-lg" aria-hidden="true"></i> New ticket</button>';
    $("#view").innerHTML = `${plan && plan.features?.tickets === false ? `<div class="notice warn">Tickets are a Business-plan feature. You can try them here, but they'll be limited once plan rules are enforced.</div>` : ""}
      <div class="tabs" id="ftabs" style="max-width:420px">${["active", "resolved", "all"].map((s) => `<button data-s="${s}" class="${s === filter ? "on" : ""}">${s}</button>`).join("")}</div>
      <div class="card table-wrap" id="tbl"></div>`;
    SC.$$("#ftabs button").forEach((b) => (b.onclick = () => { filter = b.dataset.s; SC.$$("#ftabs button").forEach((x) => x.classList.toggle("on", x === b)); load(); }));
    async function load() {
      let q = db.from("tickets").select("*").eq("tenant_id", T()).order("ticket_number", { ascending: false }).limit(200);
      if (filter === "active") q = q.in("status", ["new", "open", "waiting"]); else if (filter === "resolved") q = q.in("status", ["resolved", "closed"]);
      const rows = must(await q);
      $("#tbl").innerHTML = rows.length ? `<table><thead><tr><th>#</th><th>Subject</th><th>Status</th><th>Priority</th><th>Updated</th></tr></thead><tbody>${rows.map((t) => `
        <tr><td class="mono">#${t.ticket_number}</td><td>${esc(t.subject)}</td>
        <td><select data-id="${t.id}" data-f="status" style="width:auto">${opts(TSTAT, t.status)}</select></td>
        <td><select data-id="${t.id}" data-f="priority" style="width:auto">${opts(PRIOS, t.priority)}</select></td>
        <td class="muted small">${SC.ago(t.updated_at)}</td></tr>`).join("")}</tbody></table>` : '<div class="empty">No tickets.</div>';
      SC.$$("select[data-id]", $("#tbl")).forEach((s) => (s.onchange = async () => {
        const r = await db.from("tickets").update({ [s.dataset.f]: s.value }).eq("id", s.dataset.id).eq("tenant_id", T());
        r.error ? SC.toast(SC.friendly(r.error), true) : SC.toast("Saved");
      }));
    }
    $("#new").onclick = () => {
      const m = SC.modal(`<h2>New ticket</h2><form id="f"><div class="field"><label>Subject</label><input type="text" id="s" maxlength="200" required></div>
        <div class="field"><label>Priority</label><select id="p">${opts(PRIOS, "normal")}</select></div>
        <div class="row"><button class="btn primary">Create</button><button type="button" class="btn" id="x">Cancel</button></div></form>`);
      SC.$("#x", m).onclick = m.close;
      SC.$("#f", m).onsubmit = async (e) => { e.preventDefault();
        const r = await db.from("tickets").insert({ tenant_id: T(), subject: SC.$("#s", m).value.trim(), priority: SC.$("#p", m).value });
        if (r.error) return SC.toast(SC.friendly(r.error), true); m.close(); load(); };
    };
    await load();
  }

  // ================= SITES / WIDGET =================
  async function sites() {
    const rows = must(await db.from("sites").select("*").eq("tenant_id", T()).order("created_at"));
    if (isAdmin()) $("#actions").innerHTML = '<button class="btn primary" id="new"><i class="bi bi-plus-lg" aria-hidden="true"></i> Add website</button>';
    const snippet = (s) => `<script src="${SC_CONFIG.WIDGET_URL}" data-site-id="${s.public_site_id}" async><\/script>`;
    $("#view").innerHTML = `<div class="notice">The site ID is public — it identifies your widget but grants no access. Only the domains you list below are allowed to use it. The widget itself ships in Phase 2.</div>` +
      (rows.length ? rows.map((s) => `<div class="card" style="margin-bottom:1rem">
        <div class="row between"><h2 style="margin:0">${esc(s.name)}</h2>${isAdmin() ? `<button class="btn sm" data-edit="${s.id}">Edit</button>` : ""}</div>
        <p class="small muted">Site ID <span class="mono">${esc(s.public_site_id)}</span> · Allowed domains: ${s.allowed_domains.length ? s.allowed_domains.map((d) => `<span class="badge info">${esc(d)}</span>`).join(" ") : '<span class="badge warn">none — widget will be refused</span>'}</p>
        <pre class="code">${esc(snippet(s))}</pre><div style="margin-top:.5rem"><button class="btn sm" data-copy="${s.id}"><i class="bi bi-clipboard" aria-hidden="true"></i> Copy snippet</button></div></div>`).join("")
        : '<div class="card empty">No websites yet.' + (isAdmin() ? "<br>Add your first one to get an install snippet." : "") + "</div>");
    SC.$$("[data-copy]").forEach((b) => (b.onclick = () => SC.copy(snippet(rows.find((s) => s.id === b.dataset.copy)))));
    SC.$$("[data-edit]").forEach((b) => (b.onclick = () => editSite(rows.find((s) => s.id === b.dataset.edit))));
    if (isAdmin()) $("#new").onclick = () => editSite(null);
  }
  function editSite(s) {
    const w = (s && s.widget_settings) || {};
    const m = SC.modal(`<h2>${s ? "Edit website" : "Add website"}</h2><form id="f">
      <div class="field"><label>Name</label><input type="text" id="n" required maxlength="80" value="${esc(s?.name || "")}"></div>
      <div class="field"><label>Allowed domains</label><textarea id="d" placeholder="example.com&#10;shop.example.com">${esc((s?.allowed_domains || []).join("\n"))}</textarea>
        <div class="hint">One per line, no https:// or paths. The server rejects widget requests from any other origin.</div></div>
      <div class="grid g2"><div class="field"><label>Brand colour</label><input type="text" id="c" value="${esc(w.primary_color || "#1a6cf0")}" pattern="#[0-9a-fA-F]{6}"></div>
        <div class="field"><label>Position</label><select id="pos">${opts(["bottom-right", "bottom-left"], w.position || "bottom-right")}</select></div></div>
      <div class="field"><label>Welcome message</label><input type="text" id="wm" maxlength="200" value="${esc(w.welcome_message || "Hi! How can we help?")}"></div>
      <div class="row"><button class="btn primary">Save</button><button type="button" class="btn" id="x">Cancel</button></div></form>`);
    SC.$("#x", m).onclick = m.close;
    SC.$("#f", m).onsubmit = async (e) => {
      e.preventDefault();
      const domains = [...new Set(SC.$("#d", m).value.split(/[\s,]+/).map((x) => x.toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*$/, "").trim()).filter(Boolean))];
      const bad = domains.find((d) => !/^(\*\.)?[a-z0-9]([a-z0-9.-]*[a-z0-9])?(:\d+)?$/.test(d));
      if (bad) return SC.toast("Not a valid domain: " + bad, true);
      const row = { name: SC.$("#n", m).value.trim(), allowed_domains: domains,
        widget_settings: { primary_color: SC.$("#c", m).value, position: SC.$("#pos", m).value, welcome_message: SC.$("#wm", m).value } };
      const r = s ? await db.from("sites").update(row).eq("id", s.id).eq("tenant_id", T()) : await db.from("sites").insert({ ...row, tenant_id: T() });
      if (r.error) return SC.toast(SC.friendly(r.error), true);
      m.close(); SC.toast("Saved"); route();
    };
  }

  // ================= TEAM =================
  async function team() {
    const rows = must(await db.from("tenant_members").select("*").eq("tenant_id", T()).order("created_at"));
    const roles = ROLE() === "owner" ? ["owner", "admin", "agent", "developer"] : ["admin", "agent", "developer"];
    $("#view").innerHTML = `
      <div class="card table-wrap"><table><thead><tr><th>Member</th><th>Role</th><th>Status</th><th>Joined</th><th></th></tr></thead><tbody>${rows.map((m) => `
        <tr><td>${m.user_id === uid ? `<b>You</b> <span class="muted small">(${esc(sess.user.email)})</span>` : `<span class="mono">${esc(m.user_id)}</span>`}</td>
        <td><select data-u="${m.user_id}" data-f="role" style="width:auto" ${m.role === "owner" && ROLE() !== "owner" ? "disabled" : ""}>${opts(["owner", "admin", "agent", "developer"].filter((r) => roles.includes(r) || r === m.role), m.role)}</select></td>
        <td><select data-u="${m.user_id}" data-f="status" style="width:auto">${opts(["active", "invited", "disabled"], m.status)}</select></td>
        <td class="muted small">${SC.dt(m.created_at)}</td>
        <td>${m.user_id !== uid ? `<button class="btn sm danger" data-rm="${m.user_id}">Remove</button>` : ""}</td></tr>`).join("")}</tbody></table></div>
      <div class="card" style="margin-top:1rem"><h2>Add a team member</h2>
        <p class="small muted" style="margin-top:0">They must already have a SoundsCare account (they sign up at the login page, then send you their User ID from their profile). Email invitations arrive with a server function in a later phase.</p>
        <form id="add" class="row" style="align-items:flex-end"><div class="field" style="flex:2;min-width:240px;margin:0"><label>User ID</label><input type="text" id="uid" required placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" pattern="[0-9a-fA-F-]{36}"></div>
        <div class="field" style="margin:0"><label>Role</label><select id="role">${opts(roles.filter((r) => r !== "owner"), "agent")}</select></div><button class="btn primary">Add</button></form></div>
      <div class="notice" style="margin-top:1rem"><b>Your User ID:</b> <span class="mono">${uid}</span> <button class="btn sm" id="cp"><i class="bi bi-clipboard" aria-hidden="true"></i> Copy</button></div>`;
    $("#cp").onclick = () => SC.copy(uid);
    SC.$$("select[data-u]").forEach((s) => (s.onchange = async () => {
      const r = await db.from("tenant_members").update({ [s.dataset.f]: s.value }).eq("tenant_id", T()).eq("user_id", s.dataset.u);
      r.error ? (SC.toast(SC.friendly(r.error), true), team()) : SC.toast("Saved");
    }));
    SC.$$("[data-rm]").forEach((b) => (b.onclick = async () => {
      if (!confirm("Remove this member from the workspace?")) return;
      const r = await db.from("tenant_members").delete().eq("tenant_id", T()).eq("user_id", b.dataset.rm);
      r.error ? SC.toast(SC.friendly(r.error), true) : (SC.toast("Removed"), team());
    }));
    $("#add").onsubmit = async (e) => { e.preventDefault();
      const r = await db.from("tenant_members").insert({ tenant_id: T(), user_id: $("#uid").value.trim(), role: $("#role").value });
      r.error ? SC.toast(/foreign key/i.test(r.error.message) ? "No account exists with that User ID." : SC.friendly(r.error), true) : (SC.toast("Member added"), team()); };
  }

  // ================= EMAIL & SMS =================
  // Secrets are typed here once, sent over HTTPS to a server function, stored in a vault, and never sent back to this page.
  const FN_ERR = { secret_required: "Enter the password or API key.", bad_port: "Use port 465, 587 or 2525.", host_not_found: "That mail server address could not be found.",
    bad_host: "That mail server address isn't allowed.", forbidden: "Only workspace owners and admins can change providers.", slow_down: "Too many attempts. Wait a minute and try again.",
    bad_from: "Enter a valid 'from' email address.", bad_number: "Use international format, e.g. +254712345678.", label_required: "Give the connection a name.",
    username_required: "Enter the provider username.", bad_sender_id: "Sender ID: up to 11 letters or digits." };
  async function fn(name, body) {
    const r = await db.functions.invoke(name, { body: { tenant_id: T(), ...body } });
    if (r.error) { let j = {}; try { j = await r.error.context.json(); } catch {} throw new Error(FN_ERR[j.error] || j.detail || j.error || "Something went wrong. Please try again."); }
    return r.data;
  }
  async function integrations() {
    const [rows, dels] = await Promise.all([
      db.from("provider_connections").select("id, provider_type, label, config, status, created_at").eq("tenant_id", T()).order("created_at").then(must),
      db.from("message_deliveries").select("id, channel, recipient_masked, status, error_code, created_at").eq("tenant_id", T()).order("created_at", { ascending: false }).limit(50).then(must)]);
    const plan = planOf(), f = plan?.features || {};
    if (isAdmin()) $("#actions").innerHTML = '<button class="btn" id="addsms"><i class="bi bi-chat-text" aria-hidden="true"></i> Add SMS</button><button class="btn primary" id="addsmtp"><i class="bi bi-envelope-plus" aria-hidden="true"></i> Add SMTP</button>';
    const detail = (p) => p.provider_type === "smtp" ? `${esc(p.config.host)}:${esc(p.config.port)} · ${esc(p.config.from_email)}` : `Africa's Talking · ${esc(p.config.username)}${p.config.sender_id ? " · sender " + esc(p.config.sender_id) : ""}${p.config.sandbox ? " · sandbox" : ""}`;
    const base = SC_CONFIG.SUPABASE_URL + "/functions/v1/api-v1";
    $("#view").innerHTML = `
      <div class="notice"><i class="bi bi-lock" aria-hidden="true"></i> Passwords and API keys are stored encrypted on our servers. After you save them they can't be viewed again, only replaced.
        Mail and SMS providers may process message content in order to deliver it.</div>
      ${(f.smtp === false || f.sms === false) ? `<div class="notice warn">Your ${esc(plan?.name || "")} plan includes ${[f.smtp && "email", f.sms && "SMS"].filter(Boolean).join(" and ") || "no messaging"}. You can set up providers now, but sending through the API needs a plan that includes it.</div>` : ""}
      <div class="card table-wrap"><h2>Connections</h2>${rows.length ? `<table><thead><tr><th>Name</th><th>Type</th><th>Status</th><th></th></tr></thead><tbody>${rows.map((p) => `
        <tr><td>${esc(p.label)}<div class="small muted">${detail(p)}</div></td><td>${p.provider_type === "smtp" ? "Email (SMTP)" : "SMS"}</td><td>${SC.badge(p.status)}</td>
        <td>${isAdmin() ? `<div class="row" style="flex-wrap:nowrap"><button class="btn sm" data-test="${p.id}">Test</button><button class="btn sm" data-edit="${p.id}">Edit</button><button class="btn sm danger" data-del="${p.id}" aria-label="Delete"><i class="bi bi-trash" aria-hidden="true"></i></button></div>` : ""}</td></tr>`).join("")}</tbody></table>`
        : '<div class="empty">No email or SMS providers connected yet.</div>'}</div>
      <div class="card table-wrap" style="margin-top:1rem"><h2>Delivery log</h2>
        <p class="small muted" style="margin-top:0">"Sent" means the provider accepted it. It only says "Delivered" once the provider confirms. Message text is never stored, and recipients are partly hidden.</p>
        ${dels.length ? `<table><thead><tr><th>When</th><th>Type</th><th>To</th><th>Status</th><th>Detail</th></tr></thead><tbody>${dels.map((d) => `
        <tr><td class="small">${SC.dt(d.created_at)}</td><td>${d.channel === "sms" ? "SMS" : "Email"}</td><td class="mono">${esc(d.recipient_masked)}</td><td>${SC.badge(d.status)}</td><td class="small muted">${esc(d.error_code || "")}</td></tr>`).join("")}</tbody></table>` : '<div class="empty">Nothing sent yet.</div>'}</div>
      <div class="card" style="margin-top:1rem"><h2>Send from your own systems</h2>
        <p class="small muted" style="margin-top:0">Create a key with the <span class="mono">sms:send</span> or <span class="mono">email:send</span> scope under <a href="#/api">API keys</a>, then call it from your server. Never put the key in website code.</p>
        <pre class="code">curl -X POST ${esc(base)}/sms/send \\
  -H "Authorization: Bearer sc_live_YOUR_KEY" \\
  -H "Idempotency-Key: order-1042-confirmation" \\
  -H "Content-Type: application/json" \\
  -d '{"to":"+254712345678","message":"Your order has shipped."}'

curl ${esc(base)}/sms/status/MESSAGE_ID -H "Authorization: Bearer sc_live_YOUR_KEY"</pre>
        <p class="small muted" style="margin-bottom:0">Reusing an Idempotency-Key never sends twice. Limit: 60 requests a minute per key, plus your plan's monthly quota.</p></div>`;
    if (!isAdmin()) return;
    $("#addsmtp").onclick = () => provForm("smtp"); $("#addsms").onclick = () => provForm("sms");
    SC.$$("[data-edit]").forEach((b) => (b.onclick = () => provForm(rows.find((p) => p.id === b.dataset.edit).provider_type, rows.find((p) => p.id === b.dataset.edit))));
    SC.$$("[data-del]").forEach((b) => (b.onclick = async () => {
      if (!confirm("Delete this connection and its stored secret?")) return;
      try { await fn("providers", { action: "delete", id: b.dataset.del }); SC.toast("Deleted"); integrations(); } catch (e) { SC.toast(e.message, true); }
    }));
    SC.$$("[data-test]").forEach((b) => (b.onclick = () => testConn(rows.find((p) => p.id === b.dataset.test))));
  }
  function provForm(type, p) {
    const c = p?.config || {}, smtp = type === "smtp";
    const m = SC.modal(`<h2>${p ? "Edit" : "Add"} ${smtp ? "SMTP email" : "SMS"} connection</h2><form id="f">
      <div class="field"><label>Name</label><input type="text" id="label" maxlength="80" required value="${esc(p?.label || "")}" placeholder="${smtp ? "Company mail" : "Africa's Talking"}"></div>
      ${smtp ? `<div class="grid g2"><div class="field"><label>Mail server</label><input type="text" id="host" required value="${esc(c.host || "")}" placeholder="smtp.example.com"></div>
        <div class="field"><label>Port</label><input type="number" id="port" required value="${esc(c.port || 587)}"></div></div>
        <div class="field"><label>Security</label><select id="security"><option value="starttls" ${c.security !== "ssl" ? "selected" : ""}>STARTTLS (port 587 / 2525)</option><option value="ssl" ${c.security === "ssl" ? "selected" : ""}>SSL/TLS (port 465)</option></select></div>
        <div class="field"><label>Username</label><input type="text" id="username" required autocomplete="off" value="${esc(c.username || "")}"></div>
        <div class="field"><label>Password</label><input type="password" id="secret" autocomplete="new-password" placeholder="${p ? "Leave blank to keep the saved password" : ""}" ${p ? "" : "required"}></div>
        <div class="grid g2"><div class="field"><label>From email</label><input type="email" id="from_email" required value="${esc(c.from_email || "")}"></div>
        <div class="field"><label>From name</label><input type="text" id="from_name" maxlength="80" value="${esc(c.from_name || "")}"></div></div>`
      : `<div class="field"><label>Africa's Talking username</label><input type="text" id="username" required autocomplete="off" value="${esc(c.username || "")}"></div>
        <div class="field"><label>API key</label><input type="password" id="secret" autocomplete="new-password" placeholder="${p ? "Leave blank to keep the saved key" : ""}" ${p ? "" : "required"}></div>
        <div class="field"><label>Sender ID (optional)</label><input type="text" id="sender_id" maxlength="11" value="${esc(c.sender_id || "")}"><div class="hint">Up to 11 letters or digits. It must be approved by the provider.</div></div>
        <label style="font-weight:400"><input type="checkbox" id="sandbox" ${c.sandbox ? "checked" : ""}> Sandbox / testing mode (no real SMS)</label>`}
      <div id="ferr" class="notice bad hidden" role="alert" style="margin-top:1rem"></div>
      <div class="row" style="margin-top:1rem"><button class="btn primary" id="sv">Save</button><button type="button" class="btn" id="x">Cancel</button></div></form>`);
    SC.$("#x", m).onclick = m.close;
    SC.$("#f", m).onsubmit = async (e) => {
      e.preventDefault(); const g = (id) => { const el = SC.$("#" + id, m); return el ? el.value : ""; };
      const config = smtp ? { host: g("host"), port: +g("port"), security: g("security"), username: g("username"), from_email: g("from_email"), from_name: g("from_name") }
        : { username: g("username"), sender_id: g("sender_id"), sandbox: SC.$("#sandbox", m).checked };
      SC.$("#sv", m).disabled = true;
      try {
        const r = await fn("providers", { action: "save", id: p?.id, provider_type: type, label: g("label"), config, secret: g("secret") });
        if (r.callback) {
          m.querySelector(".modal").innerHTML = `<h2>Delivery reports URL</h2><p class="small">Paste this into your Africa's Talking dashboard as the SMS delivery report callback. It contains a secret and is shown only once.</p>
            <div class="secret mono">${esc(r.callback.url)}</div><div class="row" style="margin-top:1rem"><button class="btn primary" id="cu">Copy URL</button><button class="btn" id="dn">Done</button></div>`;
          SC.$("#cu", m).onclick = () => SC.copy(r.callback.url); SC.$("#dn", m).onclick = () => { m.close(); integrations(); };
        } else { m.close(); SC.toast("Saved"); integrations(); }
      } catch (er) { const x = SC.$("#ferr", m); x.textContent = er.message; x.classList.remove("hidden"); SC.$("#sv", m).disabled = false; }
    };
  }
  function testConn(p) {
    const smtp = p.provider_type === "smtp";
    const m = SC.modal(`<h2>Test ${esc(p.label)}</h2><form id="f">${smtp ? `<p>We'll send a test email to <b>${esc(sess.user.email)}</b>.</p>`
      : `<div class="field"><label>Send a test SMS to</label><input type="text" id="to" required placeholder="+254712345678"><div class="hint">International format. This sends one real SMS unless the connection is in sandbox mode.</div></div>`}
      <div id="res" class="notice hidden" style="margin-top:1rem"></div>
      <div class="row"><button class="btn primary" id="go">Send test</button><button type="button" class="btn" id="x">Close</button></div></form>`);
    SC.$("#x", m).onclick = () => { m.close(); integrations(); };
    SC.$("#f", m).onsubmit = async (e) => {
      e.preventDefault(); const go = SC.$("#go", m), res = SC.$("#res", m); go.disabled = true; res.className = "notice"; res.textContent = "Sending…";
      try {
        const r = await fn("providers", { action: "test", id: p.id, to: smtp ? undefined : SC.$("#to", m).value.trim() });
        res.className = "notice " + (r.ok ? "ok" : "bad");
        res.textContent = r.ok ? `Accepted by the provider and sent to ${r.sent_to}. Check that it arrived.` : `Failed: ${r.error}`;
      } catch (er) { res.className = "notice bad"; res.textContent = er.message; }
      go.disabled = false;
    };
  }

  // ================= API KEYS =================
  const SCOPES = [["conversations:read", "Read conversations"], ["conversations:write", "Write conversations"], ["sms:send", "Send SMS"], ["email:send", "Send email"], ["webhooks:manage", "Manage webhooks"]];
  async function api() {
    $("#actions").innerHTML = '<button class="btn primary" id="new"><i class="bi bi-plus-lg" aria-hidden="true"></i> Create key</button>';
    const rows = must(await db.from("api_credentials")
      .select("id, name, key_prefix, scopes, last_used_at, expires_at, revoked_at, created_at").eq("tenant_id", T()).order("created_at", { ascending: false }));
    const state = (k) => k.revoked_at ? '<span class="badge bad">revoked</span>' : k.expires_at && new Date(k.expires_at) < new Date() ? '<span class="badge warn">expired</span>' : '<span class="badge ok">active</span>';
    $("#view").innerHTML = `<div class="notice">Keys are shown once, when created. We keep only a fingerprint, so a lost key can't be recovered — revoke it and make a new one. Keep keys on your server; never put them in website code.</div>
      <div class="card table-wrap">${rows.length ? `<table><thead><tr><th>Name</th><th>Key</th><th>Scopes</th><th>Last used</th><th>State</th><th></th></tr></thead><tbody>${rows.map((k) => `
        <tr><td>${esc(k.name)}<div class="small muted">${SC.dt(k.created_at)}</div></td><td class="mono">${esc(k.key_prefix)}…</td>
        <td>${k.scopes.map((s) => `<span class="badge">${esc(s)}</span>`).join(" ") || "—"}</td><td class="muted small">${k.last_used_at ? SC.ago(k.last_used_at) : "never"}</td>
        <td>${state(k)}</td><td>${k.revoked_at ? "" : `<button class="btn sm danger" data-rv="${k.id}">Revoke</button>`}</td></tr>`).join("")}</tbody></table>` : '<div class="empty">No API keys yet.</div>'}</div>`;
    SC.$$("[data-rv]").forEach((b) => (b.onclick = async () => {
      if (!confirm("Revoke this key? Anything using it stops working immediately.")) return;
      const r = await db.rpc("revoke_api_key", { p_id: b.dataset.rv });
      r.error ? SC.toast(SC.friendly(r.error), true) : (SC.toast("Key revoked"), api());
    }));
    $("#new").onclick = () => {
      const m = SC.modal(`<h2>Create API key</h2><form id="f"><div class="field"><label>Name</label><input type="text" id="n" required maxlength="80" placeholder="Production server"></div>
        <div class="field"><label>Scopes</label>${SCOPES.map(([v, l]) => `<label style="font-weight:400"><input type="checkbox" value="${v}"> ${l} <span class="mono muted">${v}</span></label>`).join("")}
          <div class="hint">Give the key only what it needs.</div></div>
        <div class="field"><label>Expires (optional)</label><input type="date" id="e" style="width:auto"></div>
        <div class="row"><button class="btn primary">Create</button><button type="button" class="btn" id="x">Cancel</button></div></form>`);
      SC.$("#x", m).onclick = m.close;
      SC.$("#f", m).onsubmit = async (e) => { e.preventDefault();
        const scopes = SC.$$("input[type=checkbox]:checked", m).map((c) => c.value), ex = SC.$("#e", m).value;
        if (!scopes.length) return SC.toast("Pick at least one scope", true);
        const r = await db.rpc("create_api_key", { p_tenant: T(), p_name: SC.$("#n", m).value, p_scopes: scopes, p_expires: ex ? new Date(ex + "T23:59:59").toISOString() : null });
        if (r.error) return SC.toast(SC.friendly(r.error), true);
        m.querySelector(".modal").innerHTML = `<h2>Copy your key now</h2><p class="small">This is the only time it's shown.</p><div class="secret mono" id="k">${esc(r.data.api_key)}</div>
          <div class="row" style="margin-top:1rem"><button class="btn primary" id="c">Copy key</button><button class="btn" id="d">I've saved it</button></div>`;
        SC.$("#c", m).onclick = () => SC.copy(r.data.api_key); SC.$("#d", m).onclick = () => { m.close(); api(); };
      };
    };
  }

  // ================= PRIVACY & SUPPORT ACCESS =================
  async function privacy() {
    const rows = must(await db.from("support_access_grants").select("*").eq("tenant_id", T()).order("created_at", { ascending: false }).limit(50));
    const st = (g) => g.revoked_at ? '<span class="badge">revoked</span>' : new Date(g.expires_at) < new Date() ? '<span class="badge">expired</span>' : '<span class="badge warn">active</span>';
    $("#view").innerHTML = `
      <div class="card"><h2>Who can read your conversations</h2>
        <ul class="small" style="margin:0;padding-left:1.1rem"><li>Your owners, admins and agents.</li><li>SoundsCare staff <b>cannot</b> — they only see account details and usage numbers.</li>
        <li>The only exception is time-limited access that <b>you</b> grant below. It ends on its own, you can end it sooner, and every grant is logged.</li></ul></div>
      ${ROLE() === "owner" ? `<div class="card" style="margin-top:1rem"><h2>Grant temporary support access</h2>
        <form id="g"><div class="grid g2"><div class="field"><label>Support engineer's ID</label><input type="text" id="pa" required pattern="[0-9a-fA-F-]{36}" placeholder="Given to you by SoundsCare support"></div>
        <div class="field"><label>Duration</label><select id="min"><option value="30">30 minutes</option><option value="60">1 hour</option><option value="120">2 hours</option><option value="240">4 hours</option></select></div></div>
        <div class="field"><label>Reason</label><input type="text" id="why" required minlength="5" maxlength="200" placeholder="e.g. Help with ticket #42"></div>
        <button class="btn primary">Grant access</button></form></div>` : `<div class="notice" style="margin-top:1rem">Only a workspace owner can grant support access.</div>`}
      <div class="card table-wrap" style="margin-top:1rem"><h2>Access history</h2>${rows.length ? `<table><thead><tr><th>Reason</th><th>Granted</th><th>Expires</th><th>State</th><th></th></tr></thead><tbody>${rows.map((g) => `
        <tr><td>${esc(g.reason)}</td><td class="small">${SC.dt(g.created_at)}</td><td class="small">${SC.dt(g.expires_at)}</td><td>${st(g)}</td>
        <td>${!g.revoked_at && new Date(g.expires_at) > new Date() ? `<button class="btn sm danger" data-rv="${g.id}">End now</button>` : ""}</td></tr>`).join("")}</tbody></table>` : '<div class="empty">No support access has ever been granted.</div>'}</div>`;
    SC.$$("[data-rv]").forEach((b) => (b.onclick = async () => { const r = await db.rpc("revoke_support_access", { p_grant: b.dataset.rv }); r.error ? SC.toast(SC.friendly(r.error), true) : (SC.toast("Access ended"), privacy()); }));
    const g = $("#g"); if (g) g.onsubmit = async (e) => { e.preventDefault();
      const r = await db.rpc("grant_support_access", { p_tenant: T(), p_platform_admin: $("#pa").value.trim(), p_minutes: +$("#min").value, p_reason: $("#why").value.trim() });
      r.error ? SC.toast(/foreign key/i.test(r.error.message) ? "That ID isn't a SoundsCare support engineer." : SC.friendly(r.error), true) : (SC.toast("Access granted"), privacy()); };
  }

  // ================= ACTIVITY =================
  async function activity() {
    const rows = must(await db.from("audit_events").select("id, actor_user_id, action, target, metadata, created_at").eq("tenant_id", T()).order("created_at", { ascending: false }).limit(100));
    $("#view").innerHTML = `<div class="notice">A record of security-relevant changes. Message text and secrets are never stored here.</div><div class="card table-wrap">${rows.length ? `<table><thead><tr><th>When</th><th>Action</th><th>By</th><th>Target</th></tr></thead><tbody>${rows.map((a) => `
      <tr><td class="small">${SC.dt(a.created_at)}</td><td><span class="mono">${esc(a.action)}</span></td><td class="small">${a.actor_user_id === uid ? "You" : esc(shortId(a.actor_user_id) || "system")}</td><td class="mono muted">${esc(shortId(a.target))}</td></tr>`).join("")}</tbody></table>` : '<div class="empty">Nothing yet.</div>'}</div>`;
  }
  drawShell(); route();   // start only once every helper above is defined
})();
