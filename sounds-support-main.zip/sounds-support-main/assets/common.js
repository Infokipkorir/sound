/* Shared helpers for every page */
(function () {
  const cfg = window.SC_CONFIG || {};
  const configured = cfg.SUPABASE_URL && !cfg.SUPABASE_URL.includes("YOUR-PROJECT");
  window.SC = { configured, db: null };
  if (configured && window.supabase) {
    SC.db = window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
    });
  }

  // Escape everything that came from a database or a visitor before it touches innerHTML.
  SC.esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  SC.$ = (sel, el = document) => el.querySelector(sel);
  SC.$$ = (sel, el = document) => [...el.querySelectorAll(sel)];

  SC.toast = (msg, bad) => {
    const t = document.createElement("div");
    t.className = "toast" + (bad ? " bad" : "");
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), bad ? 6000 : 3200);
  };

  SC.ago = (iso) => {
    const s = Math.max(0, (Date.now() - new Date(iso)) / 1000);
    if (s < 60) return "just now";
    if (s < 3600) return Math.floor(s / 60) + "m ago";
    if (s < 86400) return Math.floor(s / 3600) + "h ago";
    return new Date(iso).toLocaleDateString(undefined, { day: "numeric", month: "short" });
  };
  SC.dt = (iso) => (iso ? new Date(iso).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" }) : "—");

  SC.friendly = (err) => {
    const m = (err && err.message) || String(err);
    if (/row-level security|permission denied|forbidden|42501/i.test(m)) return "You don't have permission to do that.";
    if (/duplicate key.*slug|tenants_slug_key/i.test(m)) return "That workspace address is already taken.";
    if (/violates check constraint.*slug/i.test(m)) return "Address must be 3–40 characters: lowercase letters, numbers and hyphens.";
    if (/at least one active owner/i.test(m)) return "A workspace must keep at least one active owner.";
    return m;
  };

  SC.requireConfig = () => {
    if (configured) return true;
    document.body.innerHTML = '<div style="max-width:560px;margin:4rem auto;padding:1rem;font-family:system-ui">' +
      '<h2>Connect Supabase first</h2><p>Open <code>assets/config.js</code> and paste your new project\'s URL and anon key.</p></div>';
    return false;
  };

  SC.session = async () => (await SC.db.auth.getSession()).data.session;
  SC.requireSession = async () => {
    const s = await SC.session();
    if (!s) { location.replace("login.html?next=" + encodeURIComponent(location.pathname.split("/").pop() + location.hash)); return null; }
    return s;
  };
  SC.signOut = async () => { await SC.db.auth.signOut(); localStorage.removeItem("sc_tenant"); location.replace("login.html"); };

  SC.modal = (html) => {
    const bg = document.createElement("div");
    bg.className = "modal-bg";
    bg.innerHTML = '<div class="modal" role="dialog" aria-modal="true">' + html + "</div>";
    bg.addEventListener("click", (e) => { if (e.target === bg) bg.remove(); });
    document.body.appendChild(bg);
    bg.close = () => bg.remove();
    return bg;
  };
  SC.copy = async (text) => { try { await navigator.clipboard.writeText(text); SC.toast("Copied"); } catch { SC.toast("Copy failed", true); } };
  SC.slugify = (s) => s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 40);
  SC.badge = (v) => {
    const map = { open: "info", new: "info", pending: "warn", waiting: "warn", resolved: "ok", closed: "", active: "ok", suspended: "bad",
      urgent: "bad", high: "warn", normal: "", low: "", ok: "ok", sent: "info", delivered: "ok", failed: "bad", queued: "warn", failing: "bad", untested: "warn", disabled: "" };
    return `<span class="badge ${map[v] ?? ""}">${SC.esc(v)}</span>`;
  };
})();
