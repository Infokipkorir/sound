
window.SC_CONFIG = {
  SUPABASE_URL: "https://eormwuvliskqurkbuzpm.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_1APxG1SZ0u8fSF-tXt8VZQ_dcnC2n5d",
  WIDGET_URL: "https://https://sounds-support.vercel.app/widget.js"   // used in the install snippet (widget ships in Phase 2)
};
